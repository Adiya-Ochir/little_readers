import React from "react";
import { Brain, Heart, Users, Zap, Target, Lightbulb } from "lucide-react";

const Development = () => {
  const developmentAreas = [
    {
      icon: Brain,
      title: "Танин мэдэхүйн хөгжил",
      description: "Сэтгэхүй, санах ой, анхаарал, хэл ярианы хөгжил",
      benefits: [
        "Хэл ярианы чадвар сайжирна",
        "Санах ой, анхаарал нэмэгддэг",
        "Логик сэтгэлгээ хөгждөг",
        "Төсөөлөх чадвар бүрддэг",
      ],
      color: "primary",
    },
    {
      icon: Heart,
      title: "Сэтгэл хөдлөлийн хөгжил",
      description: "Мэдрэмж, сэтгэл хөдлөлийг ойлгох, удирдах чадвар",
      benefits: [
        "Сэтгэл хөдлөлийг илэрхийлэх",
        "Бусадын мэдрэмжийг ойлгох",
        "Стрессийг даван туулах",
        "Өөртөө итгэх итгэл нэмэгдэх",
      ],
      color: "secondary",
    },
    {
      icon: Users,
      title: "Нийгмийн хөгжил",
      description: "Бусадтай харилцах, хамтран ажиллах чадвар",
      benefits: [
        "Найз нөхөдтэй харилцах",
        "Хамтран ажиллах чадвар",
        "Эмпати хөгжүүлэх",
        "Нийгмийн дүрэм журам сурах",
      ],
      color: "primary",
    },
  ];

  const ageStages = [
    {
      age: "0-2 нас",
      title: "Нярайн үе",
      characteristics: [
        "Үндсэн итгэлцэл бүрдэх үе",
        "Хэл ярианы анхны үе шат",
        "Мотор хөдөлгөөний хөгжил",
        "Эцэг эхтэйгээ холбоо тогтоох",
      ],
      readingBenefits: [
        "Хэл ярианы үндэс суулгах",
        "Дуу авиа, хэмнэлийг мэдрэх",
        "Эцэг эхтэй эмоциональ холбоо",
        "Анхны үг, дуу авиа сурах",
      ],
    },
    {
      age: "3-5 нас",
      title: "Цэцэрлэгийн нас",
      characteristics: [
        "Тоглоомоор дамжуулан сурах",
        "Төсөөлөх чадвар хөгждөг",
        "Бие даасан байдал нэмэгддэг",
        "Асуулт их асуудаг үе",
      ],
      readingBenefits: [
        "Үгийн сан баяжих",
        "Түүхийн бүтцийг ойлгох",
        "Дүрүүдтэй өөрийгөө адилтгах",
        "Уншлагын дуртай болох",
      ],
    },
    {
      age: "6-8 нас",
      title: "Сургуулийн анхны шат",
      characteristics: [
        "Албан ёсны сургалт эхлэх",
        "Дүрэм журам сурах",
        "Найз нөхөдтэй харилцах",
        "Өөрөө уншиж сурах",
      ],
      readingBenefits: [
        "Уншлагын техник дадал",
        "Ойлголт, шинжилгээний чадвар",
        "Академик амжилтад дэмжлэг",
        "Бие даан сурах чадвар",
      ],
    },
    {
      age: "9-12 нас",
      title: "Сургуулийн дунд шат",
      characteristics: [
        "Илүү нарийн сэтгэлгээ",
        "Найзуудын нөлөө нэмэгддэг",
        "Хувийн сонирхол тодрох",
        "Хариуцлага ухамсар нэмэгддэг",
      ],
      readingBenefits: [
        "Нарийн түвшний ойлголт",
        "Шүүмжлэлт сэтгэлгээ",
        "Өөрийн үзэл бодол бүрдүүлэх",
        "Мэдлэгийн өргөн хүрээ",
      ],
    },
  ];

  const readingImpacts = [
    {
      icon: Zap,
      title: "Тархины хөгжил",
      description:
        "Уншлага нь тархины олон хэсгийг идэвхжүүлж, нейрон холбоосыг бэхжүүлдэг",
    },
    {
      icon: Target,
      title: "Анхаарлын төвлөрөл",
      description:
        "Тогтмол уншлага нь анхаарлын хугацааг уртасгаж, төвлөрөх чадварыг сайжруулдаг",
    },
    {
      icon: Lightbulb,
      title: "Бүтээлч сэтгэлгээ",
      description:
        "Төсөөлөх чадвар, бүтээлч сэтгэлгээ, асуудал шийдвэрлэх чадвар хөгждөг",
    },
  ];

  return (
    <div className="gradient-bg min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Хүүхдийн хөгжил
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Хүүхдийн хөгжлийн шат, онцлог болон уншлагын нөлөөллийн талаарх
            мэдээлэл
          </p>
        </div>

        {/* Development Areas */}
        <section className="mb-20">
          <h2 className="section-title">Хөгжлийн үндсэн чиглэлүүд</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {developmentAreas.map((area, index) => (
              <div key={index} className="card p-6">
                <area.icon
                  className={`h-12 w-12 text-${area.color}-500 mb-4`}
                />
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  {area.title}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {area.description}
                </p>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">
                    Уншлагын ач тус:
                  </h4>
                  <ul className="space-y-1">
                    {area.benefits.map((benefit, idx) => (
                      <li
                        key={idx}
                        className="text-sm text-gray-600 flex items-start"
                      >
                        <span className={`text-${area.color}-500 mr-2`}>•</span>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Age Stages */}
        <section className="mb-20">
          <h2 className="section-title">Насны шатны онцлог</h2>
          <div className="space-y-8">
            {ageStages.map((stage, index) => (
              <div key={index} className="card p-8">
                <div className="flex flex-col lg:flex-row lg:items-start lg:space-x-8">
                  <div className="lg:w-1/3 mb-6 lg:mb-0">
                    <h3 className="text-2xl font-bold text-primary-600 mb-2">
                      {stage.age}
                    </h3>
                    <h4 className="text-xl font-semibold text-gray-800 mb-4">
                      {stage.title}
                    </h4>
                    <div>
                      <h5 className="font-semibold text-gray-800 mb-2">
                        Онцлог шинж:
                      </h5>
                      <ul className="space-y-1">
                        {stage.characteristics.map((char, idx) => (
                          <li
                            key={idx}
                            className="text-gray-600 flex items-start"
                          >
                            <span className="text-secondary-500 mr-2">•</span>
                            {char}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="lg:w-2/3">
                    <h5 className="font-semibold text-gray-800 mb-3">
                      Уншлагын ач тус энэ насанд:
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {stage.readingBenefits.map((benefit, idx) => (
                        <div key={idx} className="bg-primary-50 p-4 rounded-lg">
                          <p className="text-gray-700 flex items-start">
                            <span className="text-primary-500 mr-2">✓</span>
                            {benefit}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Reading Impact on Brain */}
        <section className="mb-20">
          <h2 className="section-title">Уншлагын тархинд үзүүлэх нөлөө</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {readingImpacts.map((impact, index) => (
              <div key={index} className="card p-6 text-center">
                <impact.icon className="h-16 w-16 text-primary-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  {impact.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {impact.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Research Facts */}
        <section className="bg-white rounded-2xl p-8 shadow-lg">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">
            Судалгааны үр дүн
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">
                90%
              </div>
              <p className="text-gray-600 text-sm">
                Тархины хөгжил 5 нас хүртэл дуусдаг
              </p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">
                1000+
              </div>
              <p className="text-gray-600 text-sm">
                Үг сонсох нь хэлний хөгжилд тусалдаг
              </p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">3x</div>
              <p className="text-gray-600 text-sm">
                Илүү их үгийн сантай болдог
              </p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">
                75%
              </div>
              <p className="text-gray-600 text-sm">
                Сургуулийн бэлтгэл сайжирдаг
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Development;
