"use client";

import React, { useEffect, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface DevelopmentArea {
  id: string;
  title: string;
  description: string;
  benefits: string[];
}

const DevelopmentManager: React.FC = () => {
  const [data, setData] = useState<DevelopmentArea[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<DevelopmentArea | null>(null);
  const [formData, setFormData] = useState<Omit<DevelopmentArea, "id">>({
    title: "",
    description: "",
    benefits: [],
  });

  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch("http://localhost:5000/api/development-areas");
      const json = await res.json();
      setData(json.data || []);
    } catch (e) {
      console.error(e);
      toast({
        title: "Алдаа",
        description: "Өгөгдөл татаж чадсангүй",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSave = async () => {
    const method = editingItem ? "PUT" : "POST";
    const url = editingItem
      ? `http://localhost:5000/api/development-areas/${editingItem.id}`
      : "http://localhost:5000/api/development-areas";

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setShowDialog(false);
        setEditingItem(null);
        fetchData();
        toast({ title: "Амжилттай", description: "Хадгалагдлаа" });
      } else throw new Error();
    } catch (e) {
      console.error(e);
      toast({
        title: "Алдаа",
        description: "Хадгалах үед алдаа гарлаа",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Устгахдаа итгэлтэй байна уу?")) return;
    try {
      await fetch(`http://localhost:5000/api/development-areas/${id}`, {
        method: "DELETE",
      });
      fetchData();
    } catch (e) {
      console.error(e);
      toast({
        title: "Алдаа",
        description: "Устгах үед алдаа гарлаа",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-semibold">Хөгжлийн чиглэл</h1>
        <Button
          onClick={() => {
            setShowDialog(true);
            setEditingItem(null);
            setFormData({ title: "", description: "", benefits: [] });
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Нэмэх
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Гарчиг</TableHead>
              <TableHead>Тайлбар</TableHead>
              <TableHead>Ач тусууд</TableHead>
              <TableHead className="text-right">Үйлдэл</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item) => (
              <TableRow key={item.id}>
                <TableCell>{item.title}</TableCell>
                <TableCell className="max-w-xs truncate">
                  {item.description}
                </TableCell>
                <TableCell>
                  <ul className="list-disc ml-4 text-sm text-muted-foreground">
                    {item.benefits.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </TableCell>
                <TableCell className="text-right space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingItem(item);
                      setFormData({
                        title: item.title,
                        description: item.description,
                        benefits: item.benefits,
                      });
                      setShowDialog(true);
                    }}
                  >
                    <Edit className="w-4 h-4 mr-1" /> Засах
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(item.id)}
                  >
                    <Trash2 className="w-4 h-4 mr-1" /> Устгах
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Dialog for Add/Edit */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Хөгжлийн чиглэл засах" : "Шинээр нэмэх"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Гарчиг</Label>
              <Input
                value={formData.title}
                onChange={(e) =>
                  setFormData({ ...formData, title: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Тайлбар</Label>
              <Textarea
                rows={3}
                value={formData.description}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Ач тусууд (Enter-р тусгаарлана)</Label>
              <Textarea
                rows={3}
                placeholder="Нэг мөр бүрт нэг ач тус бичнэ үү"
                value={formData.benefits.join("\n")}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    benefits: e.target.value.split("\n"),
                  })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSave} className="w-full">
              Хадгалах
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DevelopmentManager;
